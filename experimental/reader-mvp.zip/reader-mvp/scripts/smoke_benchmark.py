"""One-command Stage-1 smoke: ingest synthetic story and analyze one segment."""
from pathlib import Path
import json
from app.db import init_db, connect
from app.ingest import ingest_text
from app.reader import analyze_next
from app.llama import LlamaClient

ROOT=Path(__file__).resolve().parents[1]
init_db()
health=LlamaClient().health()
print('llama:', health)
if not health.get('ok'):
    raise SystemExit('llama-server is offline; start it first')
text=(ROOT/'samples'/'smoke_story.txt').read_text(encoding='utf-8')
bid=ingest_text('Synthetic B17 smoke story', text, author='OpenAI test fixture', source_type='sample')
print('book_id:',bid)
res=analyze_next(bid)
print(json.dumps({k:v for k,v in res.items() if k!='output'},indent=2,ensure_ascii=False))
print('\n--- RAW MODEL OUTPUT ---\n'+res.get('output',''))
with connect() as con:
    print('\n--- OBSERVATIONS ---')
    for r in con.execute('SELECT tag,payload,spans,epistemic FROM observations WHERE book_id=? ORDER BY id',(bid,)):
        print(f"{r['tag']}: {r['payload']} [{r['spans']}] {r['epistemic']}")
