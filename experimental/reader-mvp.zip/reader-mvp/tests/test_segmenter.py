from app.segmenter import Para, plan_segments

def test_plan_respects_chapter_boundary():
    ps=[Para('a',1,1,1,1000),Para('b',1,1,2,1000),Para('c',2,2,1,1000)]
    plans=plan_segments(ps,2500)
    assert len(plans)==2
    assert plans[0].chapter==1 and plans[1].chapter==2
