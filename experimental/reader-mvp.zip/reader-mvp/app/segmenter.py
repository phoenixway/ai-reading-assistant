from __future__ import annotations
from dataclasses import dataclass
from .textutil import paragraphs, CHAPTER_RE, SCENE_BREAK_RE
from .llama import LlamaClient

@dataclass
class Para:
    text: str
    chapter: int
    scene: int
    para: int
    tok_len: int

@dataclass
class SegmentPlan:
    chapter: int
    paras: list[Para]
    tok_len: int


def parse_paras(text: str, llama: LlamaClient) -> list[Para]:
    out: list[Para] = []
    chapter = 1
    scene = 1
    para_no = 0
    for block in paragraphs(text):
        if CHAPTER_RE.match(block):
            if out:
                chapter += 1
                scene += 1
            para_no = 0
        elif SCENE_BREAK_RE.match(block):
            scene += 1
        para_no += 1
        out.append(Para(block, chapter, scene, para_no, llama.token_count(block)))
    return out


def plan_segments(paras: list[Para], target: int = 2500, min_fill: float = 0.55) -> list[SegmentPlan]:
    plans: list[SegmentPlan] = []
    cur: list[Para] = []
    cur_tok = 0
    cur_ch = paras[0].chapter if paras else 1

    def flush():
        nonlocal cur, cur_tok, cur_ch
        if cur:
            plans.append(SegmentPlan(cur_ch, cur, cur_tok))
            cur = []
            cur_tok = 0

    for p in paras:
        hard_boundary = p.chapter != cur_ch
        if hard_boundary and cur:
            flush()
            cur_ch = p.chapter
        if cur and cur_tok + p.tok_len > target and cur_tok >= int(target * min_fill):
            flush()
            cur_ch = p.chapter
        cur.append(p)
        cur_tok += p.tok_len
        if SCENE_BREAK_RE.match(p.text) and cur_tok >= int(target * 0.35):
            flush()
            cur_ch = p.chapter
    flush()
    return plans
