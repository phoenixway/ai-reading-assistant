from __future__ import annotations
import re
from dataclasses import dataclass, field
from .textutil import norm, slug

DEVELOPER_FAST = r"""Reasoning: low
You analyze ONE fragment of fiction and extract observations as tagged lines.
Do not invent. Do not add facts absent from the fragment.
Reply ONLY with lines `TAG: value`. No markdown, no introduction, no conclusion.
One observation per line. Omit a tag if it does not apply.

TAGS
SUM: <2-3 sentences: what happened>
WHO: <known ids or names, comma-separated>
LOC: <place>
TIME: <time or interval>
EV: <one event, <=15 words> @NN
SAY: <who> | <what they assert> @NN
ST: <who> | <field> | <value> @NN
KN: <who> | <what they learned> | <from whom or -> @NN
REL: <who> -> <to whom> | <type> | <reason <=8 words> @NN
TH+: <new unresolved question/thread>
TH-: <thread resolved> | <how>
DET: <specific named object, number, promise, concrete odd detail> | <note> @NN
Q: <quote <=15 words> @NN
END: present=<id,...> | loc=<place> | situation=<literal situation at the END of fragment>

REL TYPES ONLY
help | trust_gain | trust_loss | lie_revealed | shared_secret | threat | betrayal | sacrifice | reconciliation | distance

RULES
1. @NN is the visible paragraph number. Multiple references are allowed: @03-05 or @03,@07.
2. If a CHARACTER asserts something, use SAY, not EV/ST as world fact.
3. If you infer rather than directly read it, put ? before the @ reference (or at end if no reference). Use ?? for a weak hypothesis.
4. Prefer ids from KNOWN. A new person may be written exactly as named in the text.
5. END is mandatory and describes the FINAL lines, not the main event.
"""

TAG_RE = re.compile(r'^\s*(SUM|WHO|LOC|TIME|EV|SAY|ST|KN|REL|TH\+|TH-|DET|Q|END)\s*:\s*(.+?)\s*$', re.I)
SPAN_RE = re.compile(r'@((?:\d{1,3})(?:\s*[-,]\s*@?\d{1,3})*)')
CONTENT_TAGS = {'EV','SAY','ST','KN','REL','TH+','TH-','DET','Q'}
NEEDS_SPAN = {'EV','SAY','ST','KN','REL','DET','Q'}

@dataclass
class Record:
    tag: str
    payload: str
    spans: list[int] = field(default_factory=list)
    epistemic: str = 'EXPLICIT'
    raw: str = ''

@dataclass
class Parsed:
    records: list[Record]
    ignored: list[str]
    quarantined: list[tuple[str,str]]
    stats: dict
    contract_pass: bool


def _expand_span_spec(spec: str) -> list[int]:
    out = []
    for part in re.split(r'\s*,\s*', spec):
        part = part.replace('@','').strip()
        if '-' in part:
            a,b = [int(x) for x in part.split('-',1)]
            out.extend(range(min(a,b), max(a,b)+1))
        elif part:
            out.append(int(part))
    return sorted(set(out))

def parse_output(text: str, valid_local_nos: set[int]) -> Parsed:
    records: list[Record] = []
    ignored: list[str] = []
    quarantined: list[tuple[str,str]] = []
    needed_span = 0
    valid_span = 0
    tags = set()
    for line in text.splitlines():
        if not line.strip():
            continue
        m = TAG_RE.match(line)
        if not m:
            ignored.append(line)
            continue
        tag, val = m.group(1).upper(), m.group(2).strip()
        tags.add(tag)
        spans = []
        sm = SPAN_RE.search(val)
        if sm:
            spans = _expand_span_spec(sm.group(1))
            val = (val[:sm.start()] + val[sm.end():]).strip()
        epi = 'EXPLICIT'
        q = re.search(r'\?\?\s*$', val)
        if q:
            epi = 'HYPOTHESIS'; val = val[:q.start()].strip()
        else:
            q = re.search(r'\?\s*$', val)
            if q:
                epi = 'INFERRED'; val = val[:q.start()].strip()
        if tag in NEEDS_SPAN:
            needed_span += 1
            if spans and all(x in valid_local_nos for x in spans):
                valid_span += 1
            else:
                quarantined.append((line, 'missing or invalid @NN'))
                continue
        records.append(Record(tag, val, spans, epi, line))
    lines = max(1, sum(1 for x in text.splitlines() if x.strip()))
    span_validity = valid_span / needed_span if needed_span else 1.0
    junk_ratio = len(ignored) / lines
    content_count = sum(1 for r in records if r.tag in CONTENT_TAGS)
    contract = {'SUM','WHO','END'}.issubset(tags) and content_count >= 1 and junk_ratio <= .25 and span_validity >= .80
    stats = dict(parsed=len(records), ignored=len(ignored), quarantined=len(quarantined), no_span=needed_span-valid_span,
                 span_validity=span_validity, junk_ratio=junk_ratio, content_count=content_count)
    return Parsed(records, ignored, quarantined, stats, contract)

def entity_id(name: str) -> str:
    return slug(name)

def fact_key(tag: str, payload: str) -> str:
    # deliberately simple v0.1 key; replace after benchmark if claim matching needs it
    base = norm(payload)
    return f"{tag.lower()}:{' '.join(base.split()[:8])}"
