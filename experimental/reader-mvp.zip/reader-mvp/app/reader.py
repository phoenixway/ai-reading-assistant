from __future__ import annotations
import json, re
from .db import tx, connect
from .llama import LlamaClient
from .protocol import DEVELOPER_FAST, parse_output, fact_key, entity_id
from .textutil import norm


def _segment_input(con, seg_id: str):
    rows = con.execute("""
      SELECT ss.local_no, s.id, s.pos, s.text
      FROM segment_spans ss JOIN spans s ON s.id=ss.span_id
      WHERE ss.seg_id=? ORDER BY ss.local_no
    """, (seg_id,)).fetchall()
    numbered = '\n\n'.join(f"[{r['local_no']:02}] {r['text']}" for r in rows)
    mapping = {r['local_no']: (r['id'], r['pos']) for r in rows}
    return numbered, mapping

def _known(con, book_id: int) -> str:
    rows = con.execute("SELECT id,canonical FROM entities WHERE book_id=? ORDER BY last_pos DESC LIMIT 40", (book_id,)).fetchall()
    return ', '.join(f"{r['id']}({r['canonical']})" for r in rows) or '(none yet)'

def _previous_transition(con, book_id: int, idx: int) -> str:
    r = con.execute("""
      SELECT t.* FROM transitions t JOIN segments s ON s.id=t.seg_id
      WHERE s.book_id=? AND s.idx<? ORDER BY s.idx DESC LIMIT 1
    """, (book_id, idx)).fetchone()
    if not r:
        return '(none; this is the beginning)'
    return f"present={r['present'] or ''} | loc={r['loc'] or ''} | situation={r['situation'] or ''}"

def _recent_summaries(con, book_id: int, idx: int) -> str:
    rows = con.execute("""
      SELECT sm.text FROM summaries sm JOIN segments s ON s.id=sm.seg_id
      WHERE s.book_id=? AND s.idx<? ORDER BY s.idx DESC LIMIT 2
    """, (book_id, idx)).fetchall()
    return '\n'.join(reversed([r['text'] for r in rows])) or '(none)'

def _callbacks(con, book_id: int, raw: str) -> str:
    nr = norm(raw)
    rows = con.execute("SELECT label,norm,first_span FROM details WHERE book_id=? AND status='dangling' ORDER BY introduced_pos DESC LIMIT 100", (book_id,)).fetchall()
    hits = []
    for r in rows:
        key_terms = [t for t in r['norm'].split() if len(t) >= 4]
        if key_terms and any(t in nr for t in key_terms):
            sp = con.execute("SELECT id,text FROM spans WHERE id=?", (r['first_span'],)).fetchone()
            if sp:
                hits.append(f"[{sp['id']}] {sp['text']}")
        if len(hits) >= 3:
            break
    return '\n\n'.join(hits) or '(none)'

def build_prompt(con, book_id: int, seg, task_suffix: str = '') -> tuple[list[dict], dict]:
    raw, mapping = _segment_input(con, seg['id'])
    user = f"""KNOWN: {_known(con, book_id)}
PREVIOUS SCENE END: {_previous_transition(con, book_id, seg['idx'])}
RECENT: {_recent_summaries(con, book_id, seg['idx'])}
EARLIER CALLBACKS:\n{_callbacks(con, book_id, raw)}

FRAGMENT:\n{raw}"""
    if task_suffix:
        user += '\n\nTASK OVERRIDE: ' + task_suffix
    return [
        {"role":"developer", "content":DEVELOPER_FAST},
        {"role":"user", "content":user},
    ], mapping

def _parse_end(payload: str):
    fields = {}
    for p in payload.split('|'):
        if '=' in p:
            k,v = p.split('=',1)
            fields[k.strip()] = v.strip()
    return fields.get('present',''), fields.get('loc',''), fields.get('situation','')

def _subj_obj(tag: str, payload: str):
    if tag in {'SAY','ST','KN'}:
        parts = [x.strip() for x in payload.split('|')]
        return (entity_id(parts[0]) if parts else None, None)
    if tag == 'REL':
        left = payload.split('|',1)[0]
        if '->' in left:
            a,b = [entity_id(x.strip()) for x in left.split('->',1)]
            return a,b
    return None,None

def apply_parsed(con, book_id: int, seg, parsed, mapping):
    local_to_span = {k:v[0] for k,v in mapping.items()}
    local_to_pos = {k:v[1] for k,v in mapping.items()}
    summary = next((r.payload for r in parsed.records if r.tag == 'SUM'), '')
    if summary:
        con.execute("INSERT OR REPLACE INTO summaries(seg_id,book_id,ref,pos_start,pos_end,text) VALUES(?,?,?,?,?,?)",
                    (seg['id'], book_id, seg['id'], seg['start_pos'], seg['end_pos'], summary))
    who = next((r.payload for r in parsed.records if r.tag == 'WHO'), '')
    for name in [x.strip() for x in who.split(',') if x.strip()]:
        eid = entity_id(name)
        con.execute("INSERT OR IGNORE INTO entities(id,book_id,canonical,first_pos,last_pos) VALUES(?,?,?,?,?)", (eid,book_id,name,seg['start_pos'],seg['end_pos']))
        con.execute("UPDATE entities SET last_pos=? WHERE book_id=? AND id=?", (seg['end_pos'],book_id,eid))
        con.execute("INSERT OR IGNORE INTO aliases(book_id,norm,entity_id,form) VALUES(?,?,?,?)", (book_id,norm(name),eid,name))
    for r in parsed.records:
        if r.tag in {'SUM','WHO','LOC','TIME','END'}:
            continue
        spans = [local_to_span[x] for x in r.spans if x in local_to_span]
        pos = min((local_to_pos[x] for x in r.spans if x in local_to_pos), default=seg['start_pos'])
        subj,obj = _subj_obj(r.tag, r.payload)
        source = f"CHAR:{subj}" if r.tag == 'SAY' and subj else 'NAR'
        cur = con.execute("""INSERT INTO observations(book_id,seg_id,pos,tag,kind,subj,obj,payload,source,epistemic,fact_key,spans,raw_line)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                          (book_id,seg['id'],pos,r.tag,r.tag.lower(),subj,obj,r.payload,source,r.epistemic,fact_key(r.tag,r.payload),','.join(spans),r.raw))
        oid = cur.lastrowid
        con.execute("INSERT INTO observations_fts(obs_id,book_id,payload) VALUES(?,?,?)", (oid,book_id,r.payload))
        if r.tag == 'DET' and spans:
            label = r.payload.split('|',1)[0].strip()
            con.execute("INSERT INTO details(book_id,label,norm,first_span,introduced_pos) VALUES(?,?,?,?,?)", (book_id,label,norm(label),spans[0],pos))
        elif r.tag == 'TH+':
            con.execute("INSERT INTO threads(book_id,title,opened_pos) VALUES(?,?,?)", (book_id,r.payload,pos))
        elif r.tag == 'TH-':
            title = r.payload.split('|',1)[0].strip()
            th = con.execute("SELECT id FROM threads WHERE book_id=? AND status='open' AND title LIKE ? ORDER BY opened_pos DESC LIMIT 1", (book_id, f"%{title}%")).fetchone()
            if th:
                con.execute("UPDATE threads SET status='closed',closed_pos=? WHERE id=?", (pos,th['id']))
    end = next((r for r in parsed.records if r.tag == 'END'), None)
    if end:
        present, loc, situation = _parse_end(end.payload)
        con.execute("INSERT OR REPLACE INTO transitions(seg_id,book_id,present,loc,situation) VALUES(?,?,?,?,?)", (seg['id'],book_id,present,loc,situation))

def analyze_next(book_id: int) -> dict:
    llama = LlamaClient()
    with tx() as con:
        seg = con.execute("SELECT * FROM segments WHERE book_id=? AND status='pending' ORDER BY idx LIMIT 1", (book_id,)).fetchone()
        if not seg:
            return {"done": True}
        messages, mapping = build_prompt(con, book_id, seg)
    output, elapsed = llama.chat(messages)
    parsed = parse_output(output, set(mapping.keys()))
    profile = 'FAST'

    if not parsed.contract_pass:
        # ROBUST-A: two independent extractors over the same original context.
        # Neither call sees the other's generated digest.
        with tx() as con:
            seg2 = con.execute("SELECT * FROM segments WHERE id=?", (seg['id'],)).fetchone()
            m1, _ = build_prompt(con, book_id, seg2,
                'Output ONLY SUM, WHO, LOC, TIME, EV, SAY, Q, END. END remains mandatory.')
            m2, _ = build_prompt(con, book_id, seg2,
                'Output ONLY ST, KN, REL, DET, TH+, TH-. Do not output narrative summary.')
        out1, e1 = llama.chat(m1)
        out2, e2 = llama.chat(m2)
        robust_output = out1.rstrip() + '\n' + out2.lstrip()
        robust_parsed = parse_output(robust_output, set(mapping.keys()))
        output = '--- FAST (failed contract) ---\n' + output + '\n\n--- ROBUST-A ---\n' + robust_output
        elapsed += e1 + e2
        parsed = robust_parsed
        profile = 'ROBUST-A'

    with tx() as con:
        seg = con.execute("SELECT * FROM segments WHERE id=?", (seg['id'],)).fetchone()
        for raw, reason in parsed.quarantined:
            con.execute("INSERT INTO quarantine(seg_id,raw,reason) VALUES(?,?,?)", (seg['id'], raw, reason))
        if parsed.contract_pass:
            apply_parsed(con, book_id, seg, parsed, mapping)
            con.execute("UPDATE segments SET status='done' WHERE id=?", (seg['id'],))
        else:
            con.execute("UPDATE segments SET status='needs_review' WHERE id=?", (seg['id'],))
        density = parsed.stats['content_count'] / max(.001, seg['tok_len']/1000)
        con.execute("""INSERT INTO run_log(seg_id,profile,model,reasoning,parsed,ignored,quarantined,no_span,density,span_validity,contract_pass,elapsed)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (seg['id'],profile,llama.model_name(),'low',parsed.stats['parsed'],parsed.stats['ignored'],parsed.stats['quarantined'],parsed.stats['no_span'],density,parsed.stats['span_validity'],1 if parsed.contract_pass else 0,elapsed))
        return {"done": False, "segment": seg['id'], "profile": profile, "contract_pass": parsed.contract_pass, "stats": parsed.stats, "density": density, "elapsed": elapsed, "output": output}
